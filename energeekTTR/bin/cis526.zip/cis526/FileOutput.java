/**
 * 
 */
package cis526;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

/**
 * @author yucongli
 *
 */
public class FileOutput {

    public static void writeFile(String fileName, String writeStr) {
        BufferedWriter writer = null;
        try {
            //create a temporary file
            File logFile = new File("./output/" + fileName);

            writer = new BufferedWriter(new FileWriter(logFile));
            writer.write(writeStr);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                // Close the writer regardless of what happens
                writer.close();
            } catch (Exception e) {
            }
        }
    }
}
