/**
 * 
 */
package cis526;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import BLEU.BLEU;

/**
 * @author yucongli
 *
 */
public class FinalProject {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalProject finalP = new FinalProject();
		finalP.run();
	}

	/**
	 * 
	 */
	public void run(){
		long startT = System.currentTimeMillis(); //timer start
		
		//when only have raw data, please run the following 2 methods
		//to generate ID and score files in ./output and ./output/translatorPerformance
//		maxAvrScoreForAll();
//		writeTranslatorPerformance();
		
//		RandomPrune r = new RandomPrune();
//		ArrayList<String> tmp = r.prune(27);
//		System.out.println(tmp);
//		System.out.println(tmp.size());
		
		AvrRankPrune r = new AvrRankPrune();
		ArrayList<String> tmp = r.prune(18);
		System.out.println(tmp);
		System.out.println(tmp.size());
		
		System.out.println((System.currentTimeMillis() - startT) / 1000.0); //timer end
	}
	
	public void writeTranslatorPerformance() {
		HashMap<String, String> transP = mapTranslatorPerformance();
		//counter
		int i = 1;
		
		Iterator<Entry<String, String>> iter = transP.entrySet().iterator();
        while (iter.hasNext()) {
        	Map.Entry<String, String> entry = (Map.Entry<String, String>) iter.next();
        	Object key = entry.getKey();
        	Object val = entry.getValue();
        	
        	FileOutput.writeFile("/translatorPerformance/translator" + i + ".txt", 
        			(String)key + (String)val);
        	i++;
        }
	}
	
	/**
	 * 
	 * @return
	 */
	public HashMap<String, String> mapTranslatorPerformance() {
		//translatorPerformance 
		HashMap<String, String> transP = new HashMap<String, String>();
		
		final int sntnsNum = 1683; //1683 files in total
		int sntnsIdx = 1;
		double tmpScore;
		
		while(sntnsIdx <= sntnsNum) {
			//gather data
			TranslationDataInputFormat oneSentData = readTransSntnsData(sntnsIdx);
			String[] lst = oneSentData.getRefList();
			HashMap<String, String> dct = oneSentData.getTransDict();
	        
	        //traverse all the translated sentence for one Urdu sentence
	        //and find the highest score
	        Iterator<Entry<String, String>> iter = dct.entrySet().iterator();
	        while (iter.hasNext()) {
	        	Map.Entry<String, String> entry = (Map.Entry<String, String>) iter.next();
	        	Object key = entry.getKey();
	        	Object val = entry.getValue();
	        	tmpScore = BLEU.computeSentenceBleu(lst, (String)val);
	        	if (!transP.containsKey(key)) {
	        		transP.put((String)key, "\n" + sntnsIdx + "\n" + tmpScore);
	        	} else {
	        		transP.put((String)key, transP.get((String)key) + "\n" + sntnsIdx + "\n" + tmpScore);
	        	}
	        }
	        sntnsIdx++;
		}
		//System.out.println(transP);
		return transP;
	}
	
	/**
	 * 
	 * @return
	 */
	public double writeMaxAvrScoreForAll(){
		
		final int sntnsNum = 1683; //1683 files in total
		int sntnsIdx = 1;
		double scoreSum = 0;
		double scoreThis, tmp;
		
		while(sntnsIdx <= sntnsNum) {
			//gather data
			TranslationDataInputFormat oneSentData = readTransSntnsData(sntnsIdx);
			String[] lst = oneSentData.getRefList();
			HashMap<String, String> dct = oneSentData.getTransDict();
	 
			//initialize
	        scoreThis = 0;
	        
	        //traverse all the translated sentence for one Urdu sentence
	        //and find the highest score
	        Iterator<Entry<String, String>> iter = dct.entrySet().iterator();
	        while (iter.hasNext()) {
	        	Map.Entry<String, String> entry = (Map.Entry<String, String>) iter.next();
	        	//Object key = entry.getKey();
	        	Object val = entry.getValue();
	        	tmp = BLEU.computeSentenceBleu(lst, (String)val); //compute bleu score
	        	scoreThis = (tmp > scoreThis) ? tmp : scoreThis; //update scoreThis to the highest score
	        	//System.out.println(tmp);
	        }
	        //System.out.println(sntnsIdx + ": " + scoreThis);
	        scoreSum += scoreThis;
	        sntnsIdx++;
		}
		
		FileOutput.writeFile("maxAvrScoreForAll.txt", String.valueOf(scoreSum / sntnsNum));
		System.out.println("Write to \"maxAvrScoreForAll.txt\" successfully!");
		//System.out.println(scoreSum);
		return scoreSum / sntnsNum;
	}
	
	/**
	 * 
	 * @param idx
	 * @return
	 */
	public TranslationDataInputFormat readTransSntnsData(int idx){
		String tmp = String.valueOf(idx);
		return SntnsFileInput.readFile("./data/text" + tmp + ".txt");
	}
}
