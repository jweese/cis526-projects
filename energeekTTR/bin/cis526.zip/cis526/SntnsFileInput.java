/**
 * 
 */
package cis526;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * @author yucongli
 *
 */
public class SntnsFileInput {
	
	/**
	 * 
	 * @param fileName
	 */
	public static TranslationDataInputFormat readFile(String fileName){
		//store four reference sentences
		ArrayList<String> refList = new ArrayList<String>();
		//key is translator ID and value is translated sentence
		HashMap<String, String> transDict = new HashMap<String, String>();
		int lineNum = 0;
		//tmpStr1 will store translator ID, and tmpStr2 will store the corresponding sentence
		String tmpStr1 = "";
		String tmpStr2 = "";
		
		try{
			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file);
			InputStreamReader dis = new InputStreamReader(fis);
			BufferedReader reader = new BufferedReader(dis);
			
			while (lineNum < 20) {
				switch (lineNum) {
				//these lines are reference sentences
				case 1: case 3: case 5: case 7:
					refList.add(reader.readLine());
					break;
				//these lines are translator IDs
				case 9: case 12: case 15: case 18:
					tmpStr1 = reader.readLine();
					break;
				//these lines are translated sentences
				case 10: case 13: case 16: case 19:
					tmpStr2 = reader.readLine();
					transDict.put(tmpStr1, tmpStr2);
					break;
				default:
					reader.readLine();
					break;
				}
				lineNum++;
			}
			dis.close();
		} catch (IOException e) {
			System.out.println(e);
		}
		
		//transform from ArrayList to String[] for bleu score computing use
        int size = refList.size();  
        String[] array = (String[]) refList.toArray(new String[size]); 
        //return multiple collections
		TranslationDataInputFormat returnVal = new TranslationDataInputFormat(array, transDict);
		return returnVal;
	}
}