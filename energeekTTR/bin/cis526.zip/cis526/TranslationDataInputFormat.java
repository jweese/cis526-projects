/**
 * 
 */
package cis526;

import java.util.HashMap;

/**
 * @author yucongli
 *
 */
public class TranslationDataInputFormat {
	private String[] refList = new String[4];
	private HashMap<String, String> idAndTransDict = new HashMap<String, String>();
	
	public TranslationDataInputFormat(String[] refList, HashMap<String, String> transDict){
		this.refList = refList;
		this.idAndTransDict = transDict;
	}
	
	public void setData(String[] refList, HashMap<String, String> transDict){
		this.refList = refList;
		this.idAndTransDict = transDict;
	}
	
	public String[] getRefList(){
		return refList;
	}
	
	public HashMap<String, String> getTransDict(){
		return idAndTransDict;
	}
}